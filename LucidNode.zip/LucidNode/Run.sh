#!/bin/bash
./Data/node --datadir ./Data/Data init ./Data/config.json
./Data/node --datadir ./Data/Data --networkid 999 --syncmode full console
