#!/bin/bash
./Data/node --datadir ./Data/Data --networkid 999 --syncmode full console
