#!/bin/bash
./Data/node --datadir ./Data/Data init ./Data/config.json
./Data/node --datadir ./Data/Data --networkid 999 --bootnodes="enode://c0b60f97db9a073c0434ffcdcabe2ae2819934ae9c499de5407176aa3169933a3e920adcde72c9ef6aee1b0b72ce61c0ade68d325794746f3c28977cbd07d2d2@107.155.116.102:30303" --syncmode full --gcmode archive console
